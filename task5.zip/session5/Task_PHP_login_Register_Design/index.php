<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/stlye.css">
</head>
<body>
    <div class="container2">
        <h1>Welcome</h1>
        <center> <p><a href="login.php">Login</a> or <a href="register.php">Register</a> to get started.</p></center>
    </div>
</body>
</html>
